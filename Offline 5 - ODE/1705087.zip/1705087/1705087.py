# -*- coding: utf-8 -*-


"""
*************************************************************
Created on Wed Aug 28 11:07:08 2019
@author: Fahmid_1705087
*************************************************************
"""

import math
import numpy as np
from matplotlib import pyplot as plt

'''
*************************************************************
The funtions
*************************************************************
'''

accurate=.001

def fun(x,y):
    return (x+20*y)*math.sin(x*y)

def fEuler(x_initial,x_final,y,h):

    #X=[x_initial]
    #Y=[y]
    
    
    X=np.arange(x_initial,x_final,h)
    Y=[]
    
    #while x_initial<x_final:
    for i in X:
        
        x_initial=i
        #x_initial=x_initial+h
        y=y+fun(x_initial,y)*h   

        #X.append(x_initial)
        Y.append(y)

    return X,Y


def errorfEuler(x_initial,x_final,y,h):

    #X=[x_initial]
    #Y=[y]
    error=1
    
    X=np.arange(x_initial,x_final,h)
    Y=[]
    
    #while x_initial<x_final:
    for i in X:
        
        x_initial=i
        #x_initial=x_initial+h
        y=y+fun(x_initial,y)*h   

        #X.append(x_initial)
        Y.append(y)
        
    aX=np.arange(x_initial,x_final,accurate)
    aY=[]
    
    for i in aX:
        
        x_initial=i
        #x_initial=x_initial+h
        y=y+fun(x_initial,y)*h   

        #X.append(x_initial)
        aY.append(y)


    for i in aY:
        
        error=error*((aY[i]-Y[i])/aY[i])

    return error

def f2RK(x_initial,x_final,y,h,a2):
 
    
    #X=[x_initial]
    #Y=[y]
    
    X=np.arange(x_initial,x_final,h)
    Y=[]
     
    #while x_initial<x_final:
    for i in X:
        
        x_initial=i
        
        a1=1-a2
        p=(1/2)/a2
        q=(1/2)/a2
        k1=fun(x_initial,y)
        k2=fun(x_initial+p*h,y+q*k1*h)
        #x_initial=x_initial+h
        y=y+(a1*k1+a2*k2)*h
        
        #X.append(x_initial)
        Y.append(y)
        
    return X,Y

def errorf2RK(x_initial,x_final,y,h,a2):
 
    
    #X=[x_initial]
    #Y=[y]
    
    error=1
    
    X=np.arange(x_initial,x_final,h)
    Y=[]
     
    #while x_initial<x_final:
    for i in X:
        
        x_initial=i
        
        a1=1-a2
        p=(1/2)/a2
        q=(1/2)/a2
        k1=fun(x_initial,y)
        k2=fun(x_initial+p*h,y+q*k1*h)
        #x_initial=x_initial+h
        y=y+(a1*k1+a2*k2)*h
        
        #X.append(x_initial)
        Y.append(y)

    aX=np.arange(x_initial,x_final,accurate)
    aY=[]

    for i in aX:
        
        x_initial=i
        
        a1=1-a2
        p=(1/2)/a2
        q=(1/2)/a2
        k1=fun(x_initial,y)
        k2=fun(x_initial+p*h,y+q*k1*h)
        #x_initial=x_initial+h
        y=y+(a1*k1+a2*k2)*h
        
        #X.append(x_initial)
        aY.append(y)
        
    for i in aY:
        
        error=error*(aY[i]-Y[i])/aY[i]

        
    return error

def fMidpoint(x_initial,x_final,y,h):
    
    return f2RK(x_initial,x_final,y,h,1)
        
def fHuens(x_initial,x_final,y,h):
    
    return f2RK(x_initial,x_final,y,h,1/2)
    
def fRalston(x_initial,x_final,y,h):
    
    return f2RK(x_initial,x_final,y,h,2/3)

def errorf4RK(x_initial,x_final,y,h):

    
    #X=[x_initial]
    #Y=[y]
    
    error=1
    
    X=np.arange(x_initial,x_final,h)
    Y=[]
    
    #while x_initial<x_final:
    for i in X:
        
        x_initial=i
        
        k1=fun(x_initial,y)*h
        k2=fun(x_initial+h/2,y+k1/2)*h
        k3=fun(x_initial+h/2,y+k2/2)*h
        k4=fun(x_initial+h,y+k3)*h
        #x_initial=x_initial+h
        y=y+(1.0/6.0)*(k1+2*k2+2*k3+k4)   

        #X.append(x_initial)
        Y.append(y)
        
    aX=np.arange(x_initial,x_final,accurate)
    aY=[]
    
    #while x_initial<x_final:
    for i in aX:
        
        x_initial=i
        
        k1=fun(x_initial,y)*h
        k2=fun(x_initial+h/2,y+k1/2)*h
        k3=fun(x_initial+h/2,y+k2/2)*h
        k4=fun(x_initial+h,y+k3)*h
        #x_initial=x_initial+h
        y=y+(1.0/6.0)*(k1+2*k2+2*k3+k4)   

        #X.append(x_initial)
        aY.append(y)

    for i in aY:
        
        error=error*(aY[i]-Y[i])/aY[i]
        
    return error


def f4RK(x_initial,x_final,y,h):

    
    #X=[x_initial]
    #Y=[y]
    
    X=np.arange(x_initial,x_final,h)
    Y=[]
    
    #while x_initial<x_final:
    for i in X:
        
        x_initial=i
        
        k1=fun(x_initial,y)*h
        k2=fun(x_initial+h/2,y+k1/2)*h
        k3=fun(x_initial+h/2,y+k2/2)*h
        k4=fun(x_initial+h,y+k3)*h
        #x_initial=x_initial+h
        y=y+(1.0/6.0)*(k1+2*k2+2*k3+k4)   

        #X.append(x_initial)
        Y.append(y)
        
    
    return X,Y


'''
*************************************************************
Ploating Graph for Each method
Designing graph
*************************************************************
'''    

stepSize=[ 0.01,0.05,0.1,0.5 ]

plt.figure(figsize=(12,8))
plt.xlabel(" X values ",weight='bold',size='x-large')
plt.ylabel(" Y values ",weight='bold',size='x-large')
plt.title(" ### ODE curve by Euler Method ### ",weight='bold',size='x-large')

          
for i in stepSize:
    
    X,Y=fEuler(0,10,4,i)          
    #plt.scatter(X, Y,alpha=1)
    plt.plot(X,Y,label="Euler Method "+str(i))

plt.legend()
plt.show()

plt.figure(figsize=(12,8))
plt.xlabel(" X values ",weight='bold',size='x-large')
plt.ylabel(" Y values ",weight='bold',size='x-large')
plt.title(" ### ODE curve by Huen's Method ### ",weight='bold',size='x-large')

          
for i in stepSize:
    
    X,Y=fHuens(0,10,4,i)          
    #plt.scatter(X, Y,alpha=1)
    plt.plot(X,Y,label="Huen's Method "+str(i))

plt.legend()
plt.show()

plt.figure(figsize=(12,8))
plt.xlabel(" X values ",weight='bold',size='x-large')
plt.ylabel(" Y values ",weight='bold',size='x-large')
plt.title(" ### ODE curve by Mid point Method ### ",weight='bold',size='x-large')

          
for i in stepSize:
    
    X,Y=fMidpoint(0,10,4,i)          
    #plt.scatter(X, Y,alpha=1)
    plt.plot(X,Y,label="Mid point Method "+str(i))

plt.legend()
plt.show()

plt.figure(figsize=(12,8))
plt.xlabel(" X values ",weight='bold',size='x-large')
plt.ylabel(" Y values ",weight='bold',size='x-large')
plt.title(" ### ODE curve by Ralston Method ### ",weight='bold',size='x-large')

          
for i in stepSize:
    
    X,Y=fRalston(0,10,4,i)          
    #plt.scatter(X, Y,alpha=1)
    plt.plot(X,Y,label="Ralston Method "+str(i))

plt.legend()
plt.show()


plt.figure(figsize=(12,8))
plt.xlabel(" X values ",weight='bold',size='x-large')
plt.ylabel(" Y values ",weight='bold',size='x-large')
plt.title(" ### ODE curve by 4 RK Method ### ",weight='bold',size='x-large')

          
for i in stepSize:
    
    X,Y=f4RK(0,10,4,i)          
    #plt.scatter(X, Y,alpha=1)
    plt.plot(X,Y,label="4 RK Method "+str(i))

plt.legend()
plt.show()

'''
*************************************************************
Ploating Graph for Each step
Designing graph
*************************************************************
'''    

for i in stepSize :

    plt.figure(figsize=(12,8))
    plt.xlabel(" X values ",weight='bold',size='x-large')
    plt.ylabel(" Y values ",weight='bold',size='x-large')
    plt.title(" ### ODE curve all method Step Size ="+str(i)+" ### ",weight='bold',size='x-large')
    
    
    X,Y=fEuler(0,10,4,i)
    plt.plot(X,Y,label="Euler Method "+str(i))
    
    X,Y=fHuens(0,10,4,i)
    plt.plot(X,Y,label="Huen's Method "+str(i))

    X,Y=fMidpoint(0,10,4,i)          
    plt.plot(X,Y,label="Mid point Method "+str(i))
    
    X,Y=fRalston(0,10,4,i)          
    plt.plot(X,Y,label="Ralston Method "+str(i))
    
    X,Y=f4RK(0,10,4,i)          
    plt.plot(X,Y,label="4 RK Method "+str(i))

    
    plt.legend()
    plt.show()


'''
*************************************************************
Errors calculatinon
Each graph
*************************************************************
'''   

for i in stepSize :

    print(" ### ODE Errors for all method Step Size ="+str(i)+" ### ") 
    
    print("Euler Method "+str(i))
    error=errorfEuler(0,10,4,i)
    print("Error = ",error*100," %\n")
    
    print("Huen's Method "+str(i))
    error=errorf2RK(0,10,4,i,1/2)
    print("Error = ",error*100," %\n")
    
    print("Mid point Method "+str(i))
    error=errorf2RK(0,10,4,i,1)
    print("Error = ",error*100," %\n")
    
    print("Ralston Method "+str(i))
    error=errorf2RK(0,10,4,i,2/3)
    print("Error = ",error*100," %\n")
    
    print("4 RK Method "+str(i))
    error=errorf4RK(0,10,4,i)
    print("Error = ",error*100," %\n")
    
    plt.legend()
    plt.show()